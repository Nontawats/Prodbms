<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
    protected $table = "Car";

    protected $fillable = [
        'car_id','car_brand','car_generation','car_color',
        'car_licence_plate','car_priceperday','car_status','cartype_id'
    ];
    public $timestamps = false;

   
    
}
