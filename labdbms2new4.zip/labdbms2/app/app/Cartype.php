<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cartype extends Model
{
    protected $table = "Cartype";

    protected $fillable = [
        'cartype_id','cartype_name'
    ];


}
