<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $table = "Customer";

    protected $fillable = [
        'customer_id','id_human','first_name','last_name','birthdate','age','phone','email','address','gender'
    ];
    public $timestamps = false;
}
