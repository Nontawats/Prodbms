<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $table = "Employee";

    protected $fillable = [
        'employee_id','first_name','last_name','email','phone','birthdate','gender'
    ];
    public $timestamps = false;
}
