<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Car;
use App\Cartype;

class CarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $car = Car::all();
        return view('car.index',compact('car'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $cart = Cartype::all();
        return view('car.create',compact('cart'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $car = new Car;

        $request->validate([
            'car_id' => 'required|max:10',
            'car_brand' => 'required|max:10',
            'car_generation' => 'required|max:10',
            'car_color' => 'required|max:10',
            'car_licence_plate' => 'required|max:10',
            'car_priceperday' => 'required|max:10',
            'car_status' => 'required',
            'cartype_id' => 'required'
        ]);

        $car-> car_id = $request-> car_id;
        $car-> car_brand = $request-> car_brand;
        $car-> car_generation = $request-> car_generation;
        $car-> car_color = $request-> car_color;
        $car-> car_licence_plate = $request-> car_licence_plate;
        $car-> car_priceperday = $request-> car_priceperday;
        $car-> car_status = $request-> car_status;
        $car-> cartype_id = $request-> cartype_id;
        $car-> save();

        return redirect('car');
    }

  

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($cartype_id)
    {
        #$car = Car::where('cartype_id','=',$cartype_id)->where('car_status','=','พร้อมใช้')->get();
        #return view('car.index',compact('car'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $car = Car::find($id);
        return view("car.edit",compact('car'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $car = Car::find($id);

        $car-> car_id = $request-> car_id;
        $car-> car_brand = $request-> car_brand;
        $car-> car_generation = $request-> car_generation;
        $car-> car_color = $request-> car_color;
        $car-> car_licence_plate = $request-> car_licence_plate;
        $car-> car_priceperday = $request-> car_priceperday;
        $car-> car_status = $request-> car_status;
        $car-> cartype_id = $request-> cartype_id;
        $car-> update();

        return redirect('car');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $car = Car::find($id);
        $car-> delete();
        return redirect("car");
    }
}
