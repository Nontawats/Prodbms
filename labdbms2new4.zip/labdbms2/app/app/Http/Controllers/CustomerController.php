<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cus = Customer::all();
        return view('customer.index',compact('cus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('customer.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $customer = new Customer;

        $customer-> id_human = $request-> id_human;
        $customer-> first_name = $request-> first_name;
        $customer-> last_name = $request-> last_name;
        $customer-> birthdate = $request-> birthdate;
        $customer-> age = $request-> age;
        $customer-> phone = $request-> phone;
        $customer-> email = $request-> email;
        $customer-> address = $request-> address;
        $customer-> gender = $request-> gender;
        $customer-> save();

        #$data = $request-> id_human;
        #$cust = Customer::where('id_human','=',$data)->get();
        #return $cus;
        #return view('rental.create',compact('cust'));
        return redirect('customer');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $cus = Customer::find($id);
        return view("customer.edit",compact('cus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $cus = Customer::find($id);

        $cus-> id_human = $request-> id_human;
        $cus-> first_name = $request-> first_name;
        $cus-> last_name = $request-> last_name;
        $cus-> birthdate = $request-> birthdate;
        $cus-> age = $request-> age;
        $cus-> phone = $request-> phone;
        $cus-> email = $request-> email;
        $cus-> address = $request-> address;
        $cus-> gender = $request-> gender;
        $cus-> update();

        return redirect('customer');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
