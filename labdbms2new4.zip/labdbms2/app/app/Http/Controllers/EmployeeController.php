<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $emp = Employee::all();
        return view('employee.index',compact('emp'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employee.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $emp = new Employee;

        $request->validate([
            'employee_id' => 'required|max:10',
            'first_name' => 'required|max:30',
            'last_name' => 'required|max:30',
            'email' => 'required|max:30',
            'phone' => 'required|max:20',
            'birthdate' => 'required|max:20',
            'gender' => 'required'
        ]);

        $emp-> employee_id = $request-> employee_id;
        $emp-> first_name = $request-> first_name;
        $emp-> last_name = $request-> last_name;
        $emp-> email = $request-> email;
        $emp-> phone = $request-> phone;
        $emp-> birthdate = $request-> birthdate;
        $emp-> gender = $request-> gender;
        $emp-> save();

        return redirect('employee');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $emp = Employee::find($id);
        return view("employee.edit",compact('emp'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $emp = Employee::find($id);

        $emp-> employee_id = $request-> employee_id;
        $emp-> first_name = $request-> first_name;
        $emp-> last_name = $request-> last_name;
        $emp-> email = $request-> email;
        $emp-> phone = $request-> phone;
        $emp-> birthdate = $request-> birthdate;
        $emp-> gender = $request-> gender;
        $emp-> update();

        return redirect('employee');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
