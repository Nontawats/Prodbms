<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rental;
use App\Car;
use App\Employee;
use App\Customer;

class RentalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $ren = Rental::all();
        return view('rental.index',compact('ren'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $car = Car::all();
        $car2 = Car::all();
        $emp = Employee::all();
        $cus = Customer::all();
        return view('rental.create',compact('car','car2','emp','cus'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ren = new Rental;

        $request->validate([
            'rental_date' => 'required',
            'return_date' => 'required',
            'rental_status' => 'required',
            'car_id' => 'required|max:10',
            'cartype_id' => 'required|max:10',
            'employee_id' => 'required|max:10',
            'customer_id' => 'required|max:10',
            'amount' => 'required',
        ]);

        $ren-> rental_date = $request-> rental_date;
        $ren-> return_date = $request-> return_date;
        $ren-> rental_status = $request-> rental_status;
        $ren-> car_id = $request-> car_id;
        $ren-> cartype_id = $request-> cartype_id;
        $ren-> employee_id = $request-> employee_id;
        $ren-> customer_id = $request-> customer_id;
        $ren-> amount = $request-> amount;
        $ren-> save();
        

        return redirect('rental');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        #$rental = Rental::find($rental_id);
        $ren = Rental::where('id','=',$id)->first();
        #return $rental;
        return view("rental.edit",compact('ren'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $rent = Rental::find($id);

        $rent-> rental_date = $request-> rental_date;
        $rent-> return_date = $request-> return_date;
        $rent-> rental_status = $request-> rental_status;
        $rent-> car_id = $request-> car_id;
        $rent-> cartype_id = $request-> cartype_id;
        $rent-> employee_id = $request-> employee_id;
        $rent-> customer_id = $request-> customer_id;
        $rent-> update();

        return redirect('rental');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ren = Rental::where('id','=',$id);
        $ren-> delete();
        return redirect('rental');
    }
}
