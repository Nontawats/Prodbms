<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\Transfer2;

class Transfer2Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('account.transfer');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $transfer = new Transfer2;
        $request->validate([
            'ACC_NO_Source' => 'required|max:10',
            'ACC_NO_Dest' => 'required|max:10',
            'Amount' => 'required'
        ]);
        
        DB::beginTransaction();
        $transfer->ACC_NO_Source = $request->ACC_NO_Source;
        $transfer->ACC_NO_Dest = $request->ACC_NO_Dest;
        $transfer->Amount = $request->Amount;
        $savetransfer = $transfer->save();

        $saveaccsrc = DB::update("update Account set Balance=Balance - ? where ACC_NO= ?",
                    [$transfer->Amount , $transfer->ACC_NO_Source]);

        $saveaccdest = DB::update("update Account set Balance=Balance + ? where ACC_NO= ?",
                    [$transfer->Amount , $transfer->ACC_NO_Dest]);            

        if ($savetransfer && $saveaccsrc && $saveaccdest)    {
            DB::commit();
        } else {
            DB::rollback();
        }

    
        return redirect('account');
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
