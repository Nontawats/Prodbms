<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rental extends Model
{
    protected $table = "Rental";

    protected $fillable = [
        'rental_id','rental_date','return_date','car_id','cartype_id','employee_id','customer_id','amount'
    ];
    public $timestamps = false;
}
