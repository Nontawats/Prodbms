<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transfer2 extends Model
{
    protected $table = "Transfer2";

    protected $fillable = [
        'ACC_NO_Source','ACC_NO_Dest','Amount'
    ];
}
