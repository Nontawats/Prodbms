<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableCar extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Car', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->String('car_id',10);
            $table->String('car_brand',45);
            $table->String('car_generation',45);
            $table->String('car_color',45);
            $table->String('car_licence_plate',10);
            $table->String('car_priceperday');
            $table->String('car_status',10);
            $table->String('cartype_id',10);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Car');
    }
}
