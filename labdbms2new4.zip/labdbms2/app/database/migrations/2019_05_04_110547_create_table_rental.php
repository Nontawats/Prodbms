<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableRental extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Rental', function (Blueprint $table) {
            $table->String('rental_id',10);
            $table->String('rental_date',45);
            $table->String('return_date',45);
            $table->String('rental_status',10);
            $table->String('car_id',10);
            $table->String('cartype_id',10);
            $table->String('employee_id',10);
            $table->String('customer_id',10);
            $table->String('payment_id',10);

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Rental');
    }
}
