@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <form method="post" action="{{ route('account.store') }}">
                    {{ csrf_field() }}
                    <table class="table">
                        <tr>
                            <td>
                                <label for="ACC_NO">หมายเลข</label>
                            </td>
                            <td>
                                <input type="text" name="ACC_NO">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="ACC_Name">ชื่อ</label>
                            </td>
                            <td>
                                <input type="text" name="ACC_Name">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="ACC_Surname">นามสกุล</label>
                            </td>
                            <td>
                                <input type="text" name="ACC_Surname">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="balance">จำนวนเงิน</label>
                            </td>
                            <td>
                                <input type="text" name="balance">
                            </td>
                        </tr>
                        <tr>
                            <td align=center colspan=2><button class="btn btn-success" type="submit">เปิดบัญชี</button></td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
