<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.header {
  padding: 60px;
  text-align: center;
  background: #1abc9c;
  color: white;
  font-size: 30px;
}

/* Page Content */
.content {padding:20px;}
</style>
</head>
<body>

<div class="header">
  <h1>จัดการข้อมูลรถ</h1>
  <p>My supercool header</p>
</div>
@extends('layouts.app')
@section('content')

<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default" >
                <div class="panel-heading">
                <div>
                    <a href= "{{ url('/home') }}" class='btn btn-warning'>BACK</a>
                    <a href= "{{route('car.create')}}" class='btn btn-success'>ADD-CAR</a>
                </div>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">car_id</th>
                        <th scope="col">car_brand</th>
                        <th scope="col">car_generation</th>
                        <th scope="col">car_color</th>
                        <th scope="col">car_licence_plate</th>
                        <th scope="col">car_priceperday</th>
                        <th scope="col">car_status</th>
                        <th scope="col">cartype_id</th>
                        <th scope="col">operation</th>
                        <th scope="col">delete</th>
                        </tr>
                    </thead>

                    <?php $i=1; ?>
                    @foreach($car as $row)
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                            <td>{{ $row->car_id }}</td>
                            <td>{{ $row->car_brand }}</td>
                            <td>{{ $row->car_generation }}</td>
                            <td>{{ $row->car_color }}</td>
                            <td>{{ $row->car_licence_plate }}</td>
                            <td>{{ $row->car_priceperday }}</td>
                            <td>{{ $row->car_status }}</td>
                            <td>{{ $row->cartype_id }}</td>
                            <td><a href="{{route('car.edit',$row->id)}}" class="btn btn-warning">แก้ไขข้อมูล</a></td>
                            <td>
                                <form method="post" action="{{route('car.destroy',$row->id)}}">
                                @csrf
                                @method('delete')
                                <button name="delete" class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection



</body>
</html>
