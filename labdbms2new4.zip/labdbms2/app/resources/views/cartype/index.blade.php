<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.header {
  padding: 60px;
  text-align: center;
  background: #1abc9c;
  color: white;
  font-size: 30px;
}

/* Page Content */
.content {padding:20px;}
</style>
</head>
<body>

<div class="header">
  <h1>ระบบเช่ารถ</h1>
  <p>My supercool header</p>
</div>
@extends('layouts.app')
@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        
            <div class="panel panel-default">
               
                <div class="panel-heading">
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">cartype_id</th>
                        <th scope="col">cartype_name</th>
                        <th scope="col">chose</th>
                        </tr>
                    </thead>

                    <?php $i=1; ?>
                    @foreach($cartype as $row)
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo $i++; ?> </th>
                            <td>{{ $row->cartype_id }}</td>
                            
                            <td>{{ $row->cartype_name}} </td>
                            
                            <td><a href= "{{route('car.show',$row->cartype_id)}}" class='btn btn-success'>จอง</td>
                            
                        </tr>
                    </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
