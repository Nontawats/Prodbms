@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
                <div class="panel-heading">
                    <div>
                        <h2>บันทึกข้อมูลส่วนตัว</h2>
                        <br>
                    </div>
                    <br>
                    <form method="post" action="{{ route('customer.update',$cus->id) }}">
                    @csrf
                    @method("PUT")
                    <table class="table">
                        <tr>
                            <td>
                                <label for="id_human">รหัสประจำตัวประชาชน</label>
                            </td>
                            <td>
                                <input type="text" name="id_human" value="{{$cus-> id_human}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="first_name">ชื่อ</label>
                            </td>
                            <td>
                                <input type="text" name="first_name" value="{{$cus-> first_name}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="last_name">นามสกุล</label>
                            </td>
                            <td>
                                <input type="text" name="last_name" value="{{$cus-> last_name}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="birthdate">วันเกิด</label>
                            </td>
                            <td>
                                <input type="text" name="birthdate" value="{{$cus-> birthdate}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="age">อายุ</label>
                            </td>
                            <td>
                                <input type="number" name="age" value="{{$cus-> age}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="phone">Tel.</label>
                            </td>
                            <td>
                                <input type="text" name="phone" value="{{$cus-> phone}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="email">Email.</label>
                            </td>
                            <td>
                                <input type="text" name="email" value="{{$cus-> email}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="address">ที่อยู่</label>
                            </td>
                            <td>
                                <input type="text" name="address" value="{{$cus-> address}}">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="gender">เพศ</label>
                            </td>
                            <td>
                                <input type="text" name="gender" value="{{$cus-> gender}}">
                            </td>
                        </tr>
                        
                        
                        <tr>
                            <td align=center colspan=2><button class="btn btn-success" type="submit">บันทึก</button></td>
                        </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
