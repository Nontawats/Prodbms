<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.header {
  padding: 60px;
  text-align: center;
  background: #1abc9c;
  color: white;
  font-size: 30px;
}

/* Page Content */
.content {padding:20px;}
</style>
</head>
<body>

<div class="header">
  <h1>ข้อมูลลูกค้า</h1>
  <p>My supercool header</p>
</div>
@extends('layouts.app')
@section('content')

<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default" >
                <div class="panel-heading">
                <div>
                    <a href= "{{ url('/home') }}" class='btn btn-warning'>BACK</a>
                    <a href= "{{route('customer.create')}}" class='btn btn-success'>Add-Customer</a>
                
                </div>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">customer_id</th>
                        <th scope="col">id_human</th>
                        <th scope="col">first_name</th>
                        <th scope="col">last_name</th>
                        <th scope="col">birthdate</th>
                        <th scope="col">age</th>
                        <th scope="col">phone</th>
                        <th scope="col">email</th>
                        <th scope="col">address</th>
                        <th scope="col">gender</th>
                        <th scope="col">Edit</th>
                        </tr>
                    </thead>

                    <?php $i=1; ?>
                    @foreach($cus as $row)
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                            <td>{{ $row->id }}</td>
                            <td>{{ $row->id_human }}</td>
                            <td>{{ $row->first_name }}</td>
                            <td>{{ $row->last_name }}</td>
                            <td>{{ $row->birthdate }}</td>
                            <td>{{ $row->age }}</td>
                            <td>{{ $row->phone }}</td>
                            <td>{{ $row->email }}</td>
                            <td>{{ $row->address }}</td>
                            <td>{{ $row->gender }}</td>
                            <td><a href="{{route('customer.edit',$row->id)}}" class="btn btn-warning">แก้ไขข้อมูล</a></td>
                        </tr>
                    </tbody>
                    @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection



</body>
</html>
