@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
                <div class="panel-heading">
                <div>
                    <h2>เพิ่มข้อมูลพนักงาน</h2>
                    <a href="{{route('employee.index')}}" class="btn btn-warning">BACK</a>
                </div>
                <br>
                    <form method="post" action="{{route('employee.update',$emp->id)}}">
                    @csrf
                    @method("PUT")
                    <table class="table">
                        <tr>
                            <td>
                                <label for="employee_id">รหัสพนักงาน</label>
                            </td>
                            <td>
                                <input type="text" name="employee_id" value="{{$emp-> employee_id}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="first_name">ชื่อ</label>
                            </td>
                            <td>
                                <input type="text" name="first_name" value="{{$emp-> first_name}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="last_name">นามสกุล</label>
                            </td>
                            <td>
                                <input type="text" name="last_name" value="{{$emp-> last_name}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="email">email</label>
                            </td>
                            <td>
                                <input type="text" name="email" value="{{$emp-> email}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="phone">Tel.</label>
                            </td>
                            <td>
                                <input type="text" name="phone" value="{{$emp-> phone}}"> 
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="birthdate">วันเกิด</label>
                            </td>
                            <td>
                                <input type="date" name="birthdate" value="{{$emp-> birthdate}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="gender">เพศ</label>
                            </td>
                            <td>
                                <input type="text" name="gender" value="{{$emp-> gender}}">
                            </td>
                        </tr>
                        <tr>
                            <td align=center colspan=2><button class="btn btn-success" type="submit">SAVE</button></td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
