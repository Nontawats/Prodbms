@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
                <div class="panel-heading">
                    <div>
                        <h2>บันทึกข้อมูลการจอง</h2>
                        <a href="{{route('rental.index')}}" class="btn btn-warning">BACK</a>
                    </div>
                    <br>
                    <form method="post" action="{{route('rental.store')}}">
                    {{ csrf_field() }}
                    <table class="table">
                        <tr>
                            <td>
                                <label for="rental_date">วันที่จอง</label>
                            </td>
                            <td>
                                <input type="date" name="rental_date">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="return_date">วันที่คืน</label>
                            </td>
                            <td>
                                <input type="date" name="return_date">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="rental_status">สถานะ</label>
                            </td>
                            <td>
                                <input type="text" name="rental_status">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="car_id">รหัสรถ</label>
                            </td>
                            <td>
                                <select name="car_id" id="car_id">
                                @foreach($car as $id)
                                    <option value= "{{ $id->car_id }}">รหัส: {{ $id->car_id }} ประเภท: {{ $id->cartype_id }} ราคา: {{ $id->car_priceperday }} </option>
                                @endforeach
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="cartype_id">ประเภทของรถ</label>
                            </td>
                            <td>
                                <select name="cartype_id" id="cartype_id">
                                    @foreach($car2 as $id)
                                        <option value= "{{ $id->cartype_id }}"> ประเภท: {{ $id->cartype_id }} </option>
                                    @endforeach
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="employee_id">รหัสเจ้าหน้าที่</label>
                            </td>
                            <td>
                                <select name="employee_id" id="employee_id">
                                    @foreach($emp as $idd)
                                        <option value= "{{ $idd->employee_id }}"> พนักงาน: {{ $idd->employee_id }} </option>
                                    @endforeach
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="customer_id">รหัสลูกค้า</label>
                            </td>
                            <td>
                                <select name="customer_id" id="customer_id">
                                    @foreach($cus as $iddd)
                                        <option value= "{{ $iddd->id }}"> รหัสลูกค้า: {{ $iddd->id_human }} </option>
                                    @endforeach
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="amount">จำนวนเงิน</label>
                            </td>
                            <td>
                                <input type="text" name="amount">
                            </td>
                        </tr>
                        <tr>
                            <td align=center colspan=2><button class="btn btn-success" type="submit">SAVE</button></td>
                        </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
