@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
                <div class="panel-heading">
                    <div>
                        <h2>แก้ไขข้อมูลการจอง</h2>
                    </div>
                    <br>
                    <form method="post" action="{{ route('rental.update',$ren->id) }}">
                    @csrf
                    @method("PUT")
                    <table class="table">
                        <tr>
                            <td>
                                <label for="rental_date">วันที่จอง</label>
                            </td>
                            <td>
                                <input type="date" name="rental_date" value="{{$ren-> rental_date}}">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="return_date">วันที่คืน</label>
                            </td>
                            <td>
                                <input type="date" name="return_date" value="{{$ren-> return_date}}">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="rental_status">สถานะ</label>
                            </td>
                            <td>
                                <input type="text" name="rental_status" value="{{$ren-> rental_status}}">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="car_id">รหัสรถ</label>
                            </td>
                            <td>
                                <input type="text" name="car_id" value="{{$ren-> car_id}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="cartype_id">ประเภทของรถ</label>
                            </td>
                            <td>
                                <input type="text" name="cartype_id" value="{{$ren-> cartype_id}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="employee_id">รหัสเจ้าหน้าที่</label>
                            </td>
                            <td>
                                <input type="text" name="employee_id" value="{{$ren-> employee_id}}">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="customer_id">รหัสลูกค้า</label>
                            </td>
                            <td>
                                <input type="text" name="customer_id" value="{{$ren-> customer_id}}">
                            </td> 
                        </tr>
                        <tr>
                            <td>
                                <label for="amount">จำนวนเงิน</label>
                            </td>
                            <td>
                                <input type="text" name="amount" value="{{$ren-> amount}}">
                            </td>
                        </tr>
                        <tr>
                            <td align=center colspan=2><button class="btn btn-success" type="submit">SAVE</button></td>
                        </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
