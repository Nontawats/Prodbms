<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.header {
  padding: 60px;
  text-align: center;
  background: #1abc9c;
  color: white;
  font-size: 30px;
}

/* Page Content */
.content {padding:20px;}
</style>
</head>
<body>

<div class="header">
  <h1>จัดการข้อมูลรถ</h1>
  <p>My supercool header</p>
</div>

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default" >
                <div class="panel-heading">
                <div>
                    <a href= "<?php echo e(url('/home')); ?>" class='btn btn-warning'>BACK</a>
                    <a href= "<?php echo e(route('car.create')); ?>" class='btn btn-success'>ADD-CAR</a>
                </div>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">car_id</th>
                        <th scope="col">car_brand</th>
                        <th scope="col">car_generation</th>
                        <th scope="col">car_color</th>
                        <th scope="col">car_licence_plate</th>
                        <th scope="col">car_priceperday</th>
                        <th scope="col">car_status</th>
                        <th scope="col">cartype_id</th>
                        <th scope="col">operation</th>
                        <th scope="col">delete</th>
                        </tr>
                    </thead>

                    <?php $i=1; ?>
                    <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                            <td><?php echo e($row->car_id); ?></td>
                            <td><?php echo e($row->car_brand); ?></td>
                            <td><?php echo e($row->car_generation); ?></td>
                            <td><?php echo e($row->car_color); ?></td>
                            <td><?php echo e($row->car_licence_plate); ?></td>
                            <td><?php echo e($row->car_priceperday); ?></td>
                            <td><?php echo e($row->car_status); ?></td>
                            <td><?php echo e($row->cartype_id); ?></td>
                            <td><a href="<?php echo e(route('car.edit',$row->id)); ?>" class="btn btn-warning">แก้ไขข้อมูล</a></td>
                            <td>
                                <form method="post" action="<?php echo e(route('car.destroy',$row->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button name="delete" class="btn btn-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/car/index.blade.php */ ?>