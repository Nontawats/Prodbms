

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
                <div class="panel-heading">
                    <div>
                        <h2>บันทึกข้อมูลการจอง</h2>
                        <a href="<?php echo e(route('rental.index')); ?>" class="btn btn-warning">BACK</a>
                    </div>
                    <br>
                    <form method="post" action="<?php echo e(route('rental.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <table class="table">
                        <tr>
                            <td>
                                <label for="rental_date">วันที่จอง</label>
                            </td>
                            <td>
                                <input type="date" name="rental_date">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="return_date">วันที่คืน</label>
                            </td>
                            <td>
                                <input type="date" name="return_date">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="rental_status">สถานะ</label>
                            </td>
                            <td>
                                <input type="text" name="rental_status">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="car_id">รหัสรถ</label>
                            </td>
                            <td>
                                <select name="car_id" id="car_id">
                                <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value= "<?php echo e($id->car_id); ?>">รหัส: <?php echo e($id->car_id); ?> ประเภท: <?php echo e($id->cartype_id); ?> ราคา: <?php echo e($id->car_priceperday); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="cartype_id">ประเภทของรถ</label>
                            </td>
                            <td>
                                <select name="cartype_id" id="cartype_id">
                                    <?php $__currentLoopData = $car2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value= "<?php echo e($id->cartype_id); ?>"> ประเภท: <?php echo e($id->cartype_id); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="employee_id">รหัสเจ้าหน้าที่</label>
                            </td>
                            <td>
                                <select name="employee_id" id="employee_id">
                                    <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value= "<?php echo e($idd->employee_id); ?>"> พนักงาน: <?php echo e($idd->employee_id); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="customer_id">รหัสลูกค้า</label>
                            </td>
                            <td>
                                <select name="customer_id" id="customer_id">
                                    <?php $__currentLoopData = $cus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iddd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value= "<?php echo e($iddd->id); ?>"> รหัสลูกค้า: <?php echo e($iddd->id_human); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="amount">จำนวนเงิน</label>
                            </td>
                            <td>
                                <input type="text" name="amount">
                            </td>
                        </tr>
                        <tr>
                            <td align=center colspan=2><button class="btn btn-success" type="submit">SAVE</button></td>
                        </tr>

                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/rental/create.blade.php */ ?>