<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.header {
  padding: 60px;
  text-align: center;
  background: #1abc9c;
  color: white;
  font-size: 30px;
}

/* Page Content */
.content {padding:20px;}
</style>
</head>
<body>

<div class="header">
  <h1>ข้อมูลพนักงาน</h1>
  <p>My supercool header</p>
</div>

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default" >
                <div class="panel-heading">
                <div>
                    <a href= "<?php echo e(url('/home')); ?>" class='btn btn-warning'>BACK</a>
                    <a href= "<?php echo e(route('employee.create')); ?>" class='btn btn-primary'>เพิ่มข้อมูลพนักงาน</a>
                </div>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">employee_id</th>
                        <th scope="col">first_name</th>
                        <th scope="col">last_name</th>
                        <th scope="col">email</th>
                        <th scope="col">phone</th>
                        <th scope="col">birthdate</th>
                        <th scope="col">gender</th>
                        <th scope="col">Edit</th>
                        </tr>
                    </thead>

                    <?php $i=1; ?>
                    <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                            <td><?php echo e($row->employee_id); ?></td>
                            <td><?php echo e($row->first_name); ?></td>
                            <td><?php echo e($row->last_name); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><?php echo e($row->phone); ?></td>
                            <td><?php echo e($row->birthdate); ?></td>
                            <td><?php echo e($row->gender); ?></td>
                            <td><a href="<?php echo e(route('employee.edit',$row->id)); ?>" class="btn btn-warning">แก้ไขข้อมูล</a></td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/employee/index.blade.php */ ?>