

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
                <div class="panel-heading">
                <div>
                    <h2>เพิ่มข้อมูลรถ</h2>
                    <a href="<?php echo e(route('car.index')); ?>" class="btn btn-warning">BACK</a>
                </div>
                <br>
                    <form method="post" action="<?php echo e(route('car.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <table class="table">
                        <tr>
                            <td>
                                <label for="car_id">รหัสรถ</label>
                            </td>
                            <td>
                                <input type="text" name="car_id">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="car_brand">ยี่ห้อรถ</label>
                            </td>
                            <td>
                                <input type="text" name="car_brand">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="car_generation">รุ่นรถ</label>
                            </td>
                            <td>
                                <input type="text" name="car_generation">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="car_color">สีของรถ</label>
                            </td>
                            <td>
                                <input type="text" name="car_color">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="car_licence_plate">เลขทะเบียนรถ</label>
                            </td>
                            <td>
                                <input type="text" name="car_licence_plate">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="car_priceperday">ราคาเช่า/วัน</label>
                            </td>
                            <td>
                                <input type="text" name="car_priceperday">
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="car_status">สถานะของรถ</label>
                            </td>
                            <td>
                                <select name="car_status" id="car_status">
                                    <option value="Ready">Ready</option>
                                    <option value="NotReady">NotReady</option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <label for="cartype_id">รหัสประเภทรถ</label>
                            </td>
                            <td>
                            <select name="cartype_id" id="cartype_id">
                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value= "<?php echo e($type->cartype_id); ?>"> <?php echo e($type->cartype_id); ?> <?php echo e($type->cartype_name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </td>
                        </tr>
                        <tr>
                            <td align=center colspan=2><button class="btn btn-success" type="submit">SAVE</button></td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/car/create.blade.php */ ?>