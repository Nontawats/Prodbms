create database test;

use test;

create table if not exists trantest (
    id int not null auto_increment,
    val int not null,
    primary key (id)
) engine=Innodb default charset=utf8;

insert into trantest(val) value(8);
insert into trantest(val) value(10);